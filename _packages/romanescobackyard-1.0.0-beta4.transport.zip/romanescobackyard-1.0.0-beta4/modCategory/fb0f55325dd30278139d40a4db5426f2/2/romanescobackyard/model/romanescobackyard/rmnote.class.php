<?php
/**
 * @package romanescobackyard
 */
class rmNote extends xPDOSimpleObject {}
?>