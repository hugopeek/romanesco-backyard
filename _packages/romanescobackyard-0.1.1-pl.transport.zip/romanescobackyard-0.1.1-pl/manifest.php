<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for Romanesco Backyard

## Backyard 0.1.1

- Remove space / hyphen from package names

## Backyard 0.1.0

- Add PatternLab pages
- Add PatternLab lexicons',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f5632a1ee22658d66eb99da086f76b5c',
      'native_key' => 'romanescobackyard',
      'filename' => 'modNamespace/55b1444455050e214d9c23fdd61fd374.vehicle',
      'namespace' => 'romanescobackyard',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '22af4be5bac3b38790f9a705bb9cb85c',
      'native_key' => NULL,
      'filename' => 'modCategory/f1c525b3c16b788c8c56d992f3aa4358.vehicle',
      'namespace' => 'romanescobackyard',
    ),
  ),
);