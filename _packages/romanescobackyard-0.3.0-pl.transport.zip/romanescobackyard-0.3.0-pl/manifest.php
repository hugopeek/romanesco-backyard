<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for Romanesco Backyard

## Backyard 0.3.0
Released on December 19, 2016

- Add Bosons category for ContentBlocks pages
- Fill Atoms pages
- Fill Molecules pages

## Backyard 0.2.1
Released on December 9, 2016

- Create script to migrate content changes back into Backyard package
- Change folder structure to match resource URIs
- Fill Electrons pages

## Backyard 0.2.0
Released on December 9, 2016

- Add resources for front-end pattern library (still empty)
- Small lexicon and namespace corrections

## Backyard 0.1.2

- Change lexicon prefixes from \'patternlab\' to \'romanesco\' [BC]

## Backyard 0.1.1

- Remove space / hyphen from package names
- Remove replace tasks from gruntfile

## Backyard 0.1.0

- Add PatternLab pages
- Add PatternLab lexicons',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f517d367aa374a23697375b86138f435',
      'native_key' => 'romanescobackyard',
      'filename' => 'modNamespace/1c0cd5870474ed2d177ef7bb89763ba9.vehicle',
      'namespace' => 'romanescobackyard',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5a3234f55f156b52e8ba7613d33e94b3',
      'native_key' => NULL,
      'filename' => 'modCategory/e363ae8213ff841e18968889db455540.vehicle',
      'namespace' => 'romanescobackyard',
    ),
  ),
);