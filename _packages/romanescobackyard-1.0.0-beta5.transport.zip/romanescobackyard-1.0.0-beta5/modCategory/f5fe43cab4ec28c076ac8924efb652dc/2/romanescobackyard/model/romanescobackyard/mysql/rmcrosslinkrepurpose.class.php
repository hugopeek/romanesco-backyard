<?php
/**
 * @package romanescobackyard
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/rmcrosslinkrepurpose.class.php');
class rmCrosslinkRepurpose_mysql extends rmCrosslinkRepurpose {}
?>