<?php
/**
 * @package romanescobackyard
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/rmnoteissue.class.php');
class rmNoteIssue_mysql extends rmNoteIssue {}
?>