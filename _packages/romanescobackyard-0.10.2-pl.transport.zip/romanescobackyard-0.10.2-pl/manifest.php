<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0bb1ee1de68bf6dc30c2997e82205faa',
      'native_key' => 'romanescobackyard',
      'filename' => 'modNamespace/53ac42b275c4987cf31ad2ca9811a9fa.vehicle',
      'namespace' => 'romanescobackyard',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7c4c864cc0f9b9729b35ac173f7dbd60',
      'native_key' => NULL,
      'filename' => 'modCategory/db64914efea5c923a4be962204dc9f82.vehicle',
      'namespace' => 'romanescobackyard',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a5073bf22c1146c84e3c445dcb2b72fe',
      'native_key' => 'romanesco.menu.tool_shed_title',
      'filename' => 'modMenu/577e9dfc66ab41083853e8a644c8a520.vehicle',
      'namespace' => 'romanescobackyard',
    ),
  ),
);