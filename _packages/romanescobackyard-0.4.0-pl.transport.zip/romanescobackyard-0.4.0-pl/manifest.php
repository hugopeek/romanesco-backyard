<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for Romanesco Backyard

## Backyard 0.4.0
Upcoming release

- Add Tutorials and Test cases to Backyard area
- Move current categories under Backyard page to Examples subpage

## Backyard 0.3.3
Released on May 2, 2017

- Move keys for top menu items to default lexicon file
- Add keys for buttons to clear individual custom cache partitions
- Add Adaptation and Monetization pages to Backyard

## Backyard 0.3.2
Released on February 22, 2017

- Remove nonsensical test content from Backyard pages
- Corrections and additional content

## Backyard 0.3.1
Released on January 26, 2017

- Add Backyard resources
- Add Dashboard resource
- Add Universal styling under Electrons (showing the Semantic UI site.variables)
- Change alias \'pattern-library\' to \'patterns\'
- Corrections and additional content

## Backyard 0.3.0
Released on December 19, 2016

- Add Bosons category for ContentBlocks pages
- Fill Atoms pages
- Fill Molecules pages

## Backyard 0.2.1
Released on December 9, 2016

- Create script to migrate content changes back into Backyard package
- Change folder structure to match resource URIs
- Fill Electrons pages

## Backyard 0.2.0
Released on December 9, 2016

- Add resources for front-end pattern library (still empty)
- Small lexicon and namespace corrections

## Backyard 0.1.2

- Change lexicon prefixes from \'patternlab\' to \'romanesco\' [BC]

## Backyard 0.1.1

- Remove space / hyphen from package names
- Remove replace tasks from gruntfile

## Backyard 0.1.0

- Add PatternLab pages
- Add PatternLab lexicons',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3532a01ce0b6bbe1bca7f58190b28d0c',
      'native_key' => 'romanescobackyard',
      'filename' => 'modNamespace/5b38590067fd390d34b2b79cf7c40819.vehicle',
      'namespace' => 'romanescobackyard',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd39629741c6fd6227ef4a2dcb1d0122e',
      'native_key' => NULL,
      'filename' => 'modCategory/9cdf94bd582aee2912d34f4998a3b921.vehicle',
      'namespace' => 'romanescobackyard',
    ),
  ),
);