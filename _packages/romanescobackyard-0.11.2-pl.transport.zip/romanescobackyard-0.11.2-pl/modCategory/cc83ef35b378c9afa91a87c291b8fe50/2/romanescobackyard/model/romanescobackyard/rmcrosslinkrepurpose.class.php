<?php
/**
 * @package romanescobackyard
 */
class rmCrosslinkRepurpose extends xPDOSimpleObject {}
?>