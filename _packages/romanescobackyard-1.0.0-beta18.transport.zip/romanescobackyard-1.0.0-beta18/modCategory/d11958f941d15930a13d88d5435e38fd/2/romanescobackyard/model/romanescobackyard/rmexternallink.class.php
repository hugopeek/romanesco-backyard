<?php
/**
 * @package romanescobackyard
 */
class rmExternalLink extends xPDOSimpleObject {}
?>