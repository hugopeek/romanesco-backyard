<?php
/**
 * @package romanescobackyard
 */
class rmTaskResource extends rmTask {}
?>