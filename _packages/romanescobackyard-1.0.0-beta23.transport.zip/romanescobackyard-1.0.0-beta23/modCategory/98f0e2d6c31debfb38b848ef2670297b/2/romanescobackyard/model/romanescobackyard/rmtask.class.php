<?php
/**
 * @package romanescobackyard
 */
class rmTask extends xPDOSimpleObject {}
?>