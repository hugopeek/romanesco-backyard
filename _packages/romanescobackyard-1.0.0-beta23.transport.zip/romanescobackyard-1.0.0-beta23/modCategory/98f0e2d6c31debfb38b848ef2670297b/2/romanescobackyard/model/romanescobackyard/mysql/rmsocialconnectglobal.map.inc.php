<?php
/**
 * @package romanescobackyard
 */
$xpdo_meta_map['rmSocialConnectGlobal']= array (
  'package' => 'romanescobackyard',
  'version' => '1.1',
  'extends' => 'rmSocialConnect',
  'tableMeta' => 
  array (
    'engine' => 'InnoDB',
  ),
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
