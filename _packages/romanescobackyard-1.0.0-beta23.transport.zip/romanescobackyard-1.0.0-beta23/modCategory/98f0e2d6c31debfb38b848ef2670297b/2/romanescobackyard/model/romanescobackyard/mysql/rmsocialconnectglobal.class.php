<?php
/**
 * @package romanescobackyard
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/rmsocialconnectglobal.class.php');
class rmSocialConnectGlobal_mysql extends rmSocialConnectGlobal {}
?>