<?php
/**
 * @package romanescobackyard
 */
class rmSocialConnectResource extends rmSocialConnect {}
?>