<?php
/**
 * @package romanescobackyard
 */
class rmSocialConnectUser extends rmSocialConnect {}
?>