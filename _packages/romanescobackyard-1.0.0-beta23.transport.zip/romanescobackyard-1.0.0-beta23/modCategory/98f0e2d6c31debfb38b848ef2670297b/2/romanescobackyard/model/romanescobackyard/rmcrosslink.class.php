<?php
/**
 * @package romanescobackyard
 */
class rmCrossLink extends xPDOSimpleObject {}
?>