<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for Romanesco Backyard

## Backyard 0.1.2

- Change lexicon prefixes from \'patternlab\' to \'romanesco\' [BC]

## Backyard 0.1.1

- Remove space / hyphen from package names
- Remove replace tasks from gruntfile

## Backyard 0.1.0

- Add PatternLab pages
- Add PatternLab lexicons',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a3f4fcb42b4a97705f51d807dd6d88af',
      'native_key' => 'romanescobackyard',
      'filename' => 'modNamespace/52e5332a2706c92127ab68d93297115d.vehicle',
      'namespace' => 'romanescobackyard',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f8e128f76b8f9692a0d0c42937020449',
      'native_key' => NULL,
      'filename' => 'modCategory/aaa6d6b18ae51788d9709a8121b748a3.vehicle',
      'namespace' => 'romanescobackyard',
    ),
  ),
);