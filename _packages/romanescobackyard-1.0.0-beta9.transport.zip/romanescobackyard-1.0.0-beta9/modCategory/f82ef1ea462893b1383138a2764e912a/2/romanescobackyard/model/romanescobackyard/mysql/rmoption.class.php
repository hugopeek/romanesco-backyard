<?php
/**
 * @package romanescobackyard
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/rmoption.class.php');
class rmOption_mysql extends rmOption {}
?>