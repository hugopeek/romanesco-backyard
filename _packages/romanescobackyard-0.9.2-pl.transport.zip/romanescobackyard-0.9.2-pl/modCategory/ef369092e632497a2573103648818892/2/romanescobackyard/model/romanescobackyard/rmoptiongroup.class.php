<?php
/**
 * @package romanescobackyard
 */
class rmOptionGroup extends xPDOSimpleObject {}
?>