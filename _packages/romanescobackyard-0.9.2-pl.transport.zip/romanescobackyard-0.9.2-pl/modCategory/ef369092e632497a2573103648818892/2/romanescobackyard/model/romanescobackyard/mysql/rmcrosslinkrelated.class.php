<?php
/**
 * @package romanescobackyard
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/rmcrosslinkrelated.class.php');
class rmCrosslinkRelated_mysql extends rmCrosslinkRelated {}
?>