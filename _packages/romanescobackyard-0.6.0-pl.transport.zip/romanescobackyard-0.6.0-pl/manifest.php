<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => '',
    'readme' => '',
    'changelog' => '# Changelog for Romanesco Backyard

## Backyard 0.6.0
Released on July 27, 2018

- Remove popup examples with MODX code from pattern library

## Backyard 0.5.1
Released on January 16, 2018

- Add resource with CSS theme variables
- Add gulp task for generating favicons
- Add basic contact form

## Backyard 0.5.0
Released on December 19, 2017

- Import assets folder from Romanesco Soil repository
- Assign resource IDs to corresponding system settings after installation

## Backyard 0.4.2
Released on November 21, 2017

- Include content_type in resource configs (fixes undefined index PHP warnings)

## Backyard 0.4.1
Released on November 21, 2017

- Update resolver to fix installation issues

## Backyard 0.4.0
Released on July 25, 2017

- Add Tutorials and Test cases to Backyard area
- Move current categories under Backyard page to Examples subpage

## Backyard 0.3.3
Released on May 2, 2017

- Move keys for top menu items to default lexicon file
- Add keys for buttons to clear individual custom cache partitions
- Add Adaptation and Monetization pages to Backyard

## Backyard 0.3.2
Released on February 22, 2017

- Remove nonsensical test content from Backyard pages
- Corrections and additional content

## Backyard 0.3.1
Released on January 26, 2017

- Add Backyard resources
- Add Dashboard resource
- Add Universal styling under Electrons (showing the Semantic UI site.variables)
- Change alias \'pattern-library\' to \'patterns\'
- Corrections and additional content

## Backyard 0.3.0
Released on December 19, 2016

- Add Bosons category for ContentBlocks pages
- Fill Atoms pages
- Fill Molecules pages

## Backyard 0.2.1
Released on December 9, 2016

- Create script to migrate content changes back into Backyard package
- Change folder structure to match resource URIs
- Fill Electrons pages

## Backyard 0.2.0
Released on December 9, 2016

- Add resources for front-end pattern library (still empty)
- Small lexicon and namespace corrections

## Backyard 0.1.2

- Change lexicon prefixes from \'patternlab\' to \'romanesco\' [BC]

## Backyard 0.1.1

- Remove space / hyphen from package names
- Remove replace tasks from gruntfile

## Backyard 0.1.0

- Add PatternLab pages
- Add PatternLab lexicons',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '26d8978ce351427ec95d4d8bdeb0d671',
      'native_key' => 'romanescobackyard',
      'filename' => 'modNamespace/634ea3ff53cd7db6967241d4c2ef27ba.vehicle',
      'namespace' => 'romanescobackyard',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9329a8427da05462928bbdec1673bcd1',
      'native_key' => NULL,
      'filename' => 'modCategory/aaaf463e4ab6fbff70faed8fb4aa6bcb.vehicle',
      'namespace' => 'romanescobackyard',
    ),
  ),
);