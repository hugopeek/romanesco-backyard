<?php
/**
 * @package romanescobackyard
 */
class rmTimelineProject extends xPDOSimpleObject {}
?>