<?php

// System settings
// @todo: Not working, because the settings are under the romanesco namespace and these settings are only picked up under their own namespace (romanescobackyard).
// ---------------------------------------------------------------------

$_lang['setting_romanesco.cb_hide_advanced_features'] = 'Hide advanced ContentBlocks features';
$_lang['setting_romanesco.cb_hide_advanced_features_desc'] = 'Disable some of the more technical settings in ContentBlocks, like link rel attributes. Note that this only hides the settings in the manager. Defaults are still applied and changes can still be made with this configuration setting switched on.';