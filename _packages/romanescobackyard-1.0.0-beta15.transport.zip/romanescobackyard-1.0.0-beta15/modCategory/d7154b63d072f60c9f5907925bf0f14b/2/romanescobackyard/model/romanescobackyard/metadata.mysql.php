<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'rmTask',
    1 => 'rmTaskComment',
    2 => 'rmCrossLink',
    3 => 'rmExternalLink',
    4 => 'rmSocialConnect',
    5 => 'rmSocialShare',
    6 => 'rmOption',
    7 => 'rmOptionGroup',
  ),
);