<?php
/**
 * @package romanescobackyard
 */
class rmTaskComment extends xPDOSimpleObject {}
?>