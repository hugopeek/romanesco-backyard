<?php
namespace FractalFarming\Romanesco\Model;

use xPDO\xPDO;

/**
 * Class SocialConnectGlobal
 *
 *
 * @package FractalFarming\Romanesco\Model
 */
class SocialConnectGlobal extends \FractalFarming\Romanesco\Model\SocialConnect
{
}
