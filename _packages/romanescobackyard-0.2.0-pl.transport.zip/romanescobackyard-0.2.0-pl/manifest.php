<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for Romanesco Backyard

## Backyard 0.2.0

- Add resources for front-end pattern library (still empty)
- Small lexicon and namespace corrections

## Backyard 0.1.2

- Change lexicon prefixes from \'patternlab\' to \'romanesco\' [BC]

## Backyard 0.1.1

- Remove space / hyphen from package names
- Remove replace tasks from gruntfile

## Backyard 0.1.0

- Add PatternLab pages
- Add PatternLab lexicons',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cacbdfcb5c0d487dd534cae2b08c0d08',
      'native_key' => 'romanescobackyard',
      'filename' => 'modNamespace/303bbc1c19a4848328b80842610ecf91.vehicle',
      'namespace' => 'romanescobackyard',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '56a4caa6b9e731a1dcc9c7ef9f4999e9',
      'native_key' => NULL,
      'filename' => 'modCategory/03c9b10e93fba93b5b692753dbbd03ab.vehicle',
      'namespace' => 'romanescobackyard',
    ),
  ),
);