<?php
/**
 * @package romanescobackyard
 */
class rmNoteImprovement extends xPDOSimpleObject {}
?>