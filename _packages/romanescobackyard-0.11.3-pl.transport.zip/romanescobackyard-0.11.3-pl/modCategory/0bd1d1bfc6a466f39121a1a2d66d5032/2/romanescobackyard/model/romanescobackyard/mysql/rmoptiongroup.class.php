<?php
/**
 * @package romanescobackyard
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/rmoptiongroup.class.php');
class rmOptionGroup_mysql extends rmOptionGroup {}
?>