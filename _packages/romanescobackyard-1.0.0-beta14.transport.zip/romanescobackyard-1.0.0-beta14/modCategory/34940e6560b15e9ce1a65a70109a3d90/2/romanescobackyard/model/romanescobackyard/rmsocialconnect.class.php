<?php
/**
 * @package romanescobackyard
 */
class rmSocialConnect extends xPDOSimpleObject {}
?>