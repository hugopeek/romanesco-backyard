<?php
/**
 * @package romanescobackyard
 */
class rmSocialConnectGlobal extends rmSocialConnect {}
?>