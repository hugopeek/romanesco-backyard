<?php
/**
 * @package romanescobackyard
 */
class rmOption extends xPDOSimpleObject {}
?>