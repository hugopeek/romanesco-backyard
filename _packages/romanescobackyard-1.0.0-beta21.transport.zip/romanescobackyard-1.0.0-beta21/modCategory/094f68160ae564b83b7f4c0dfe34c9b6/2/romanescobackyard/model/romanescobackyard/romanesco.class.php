<?php
/**
 * @package romanescobackyard
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * class Romanesco
 */
class Romanesco extends \FractalFarming\Romanesco\Romanesco
{
}
