<?php
/**
 * @package romanescobackyard
 */
class rmSocialShare extends xPDOSimpleObject {}
?>