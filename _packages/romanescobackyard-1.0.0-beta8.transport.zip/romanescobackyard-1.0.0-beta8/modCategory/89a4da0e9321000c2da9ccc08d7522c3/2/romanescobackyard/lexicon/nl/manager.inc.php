<?php

// ContentBlocks layouts
//$_lang['Achtergrond'] = 'Background';
//$_lang['Wit'] = 'White';
//$_lang['Hoofdkleur'] = 'Primary';
//$_lang['Accent'] = 'Secondary';
//$_lang['Licht'] = 'Light';
//$_lang['Donker'] = 'Dark';
//$_lang['Patroon'] = 'Pattern';

// Collection views
