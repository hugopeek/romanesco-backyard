<?php
/**
 * @package romanescobackyard
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/rmtimelineproject.class.php');
class rmTimelineProject_mysql extends rmTimelineProject {}
?>