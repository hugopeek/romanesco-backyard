<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'rmTimeline',
    1 => 'rmNote',
    2 => 'rmCrosslink',
    3 => 'rmExternalLink',
    4 => 'rmOption',
    5 => 'rmOptionGroup',
    6 => 'rmTimelineProject',
    7 => 'rmNoteImprovement',
    8 => 'rmNoteIssue',
    9 => 'rmCrosslinkRepurpose',
    10 => 'rmCrosslinkRelated',
  ),
);