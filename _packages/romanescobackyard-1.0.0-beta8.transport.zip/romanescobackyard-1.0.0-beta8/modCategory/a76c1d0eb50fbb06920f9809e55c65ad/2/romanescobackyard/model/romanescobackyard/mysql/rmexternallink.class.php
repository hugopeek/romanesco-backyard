<?php
/**
 * @package romanescobackyard
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/rmexternallink.class.php');
class rmExternalLink_mysql extends rmExternalLink {}
?>