<?php
/**
 * @package romanescobackyard
 */
class rmTimeline extends xPDOSimpleObject {}
?>