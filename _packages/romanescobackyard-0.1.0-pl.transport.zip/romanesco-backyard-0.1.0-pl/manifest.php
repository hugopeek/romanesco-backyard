<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '# Changelog for Romanesco Backyard

## Backyard 0.1.0

- Add PatternLab pages
- Add PatternLab lexicons',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '547a0191a599ab3a80fd6fc499f39b6c',
      'native_key' => 'romanesco-backyard',
      'filename' => 'modNamespace/5a717ed929d66b60e43020190238cb7d.vehicle',
      'namespace' => 'romanesco-backyard',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7c8a1e5115042906a9350a4ed9a8fe81',
      'native_key' => NULL,
      'filename' => 'modCategory/3bf8a95d8d91c9dbb152ccc5c88b725e.vehicle',
      'namespace' => 'romanesco-backyard',
    ),
  ),
);