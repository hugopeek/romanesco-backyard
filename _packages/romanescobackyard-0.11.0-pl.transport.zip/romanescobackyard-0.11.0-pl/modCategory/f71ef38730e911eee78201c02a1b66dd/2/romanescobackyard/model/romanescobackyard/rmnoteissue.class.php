<?php
/**
 * @package romanescobackyard
 */
class rmNoteIssue extends xPDOSimpleObject {}
?>