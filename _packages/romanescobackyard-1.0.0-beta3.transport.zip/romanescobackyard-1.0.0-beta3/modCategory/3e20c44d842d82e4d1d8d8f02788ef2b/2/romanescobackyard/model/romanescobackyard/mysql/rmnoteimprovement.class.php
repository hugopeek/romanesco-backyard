<?php
/**
 * @package romanescobackyard
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/rmnoteimprovement.class.php');
class rmNoteImprovement_mysql extends rmNoteImprovement {}
?>