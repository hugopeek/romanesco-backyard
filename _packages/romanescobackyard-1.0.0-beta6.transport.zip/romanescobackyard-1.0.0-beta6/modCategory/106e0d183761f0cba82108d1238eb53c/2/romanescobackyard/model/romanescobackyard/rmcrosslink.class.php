<?php
/**
 * @package romanescobackyard
 */
class rmCrosslink extends xPDOSimpleObject {}
?>