<?php
namespace FractalFarming\Romanesco\Model;

use xPDO\xPDO;

/**
 * Class TaskResource
 *
 *
 * @package FractalFarming\Romanesco\Model
 */
class TaskResource extends \FractalFarming\Romanesco\Model\Task
{
}
