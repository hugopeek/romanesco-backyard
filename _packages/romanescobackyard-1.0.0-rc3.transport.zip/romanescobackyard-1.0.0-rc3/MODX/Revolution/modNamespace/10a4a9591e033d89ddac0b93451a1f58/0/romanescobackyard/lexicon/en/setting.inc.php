<?php

// System settings
// @todo: Not working, because the settings are under the romanesco namespace and these settings are only picked up under their own namespace (romanescobackyard).
// ---------------------------------------------------------------------

$_lang['setting_romanesco.cb_hide_fields'] = 'Hide ContentBlocks fields';
$_lang['setting_romanesco.cb_hide_fields_desc'] = 'Disable some of the more technical settings in ContentBlocks, like link rel attributes. Note that this only hides the settings in the manager. Defaults are still applied and changes can still be made in environments with this setting switched on.';