<?php
namespace FractalFarming\Romanesco\Model;

use xPDO\xPDO;

/**
 * Class SocialConnectResource
 *
 *
 * @package FractalFarming\Romanesco\Model
 */
class SocialConnectResource extends \FractalFarming\Romanesco\Model\SocialConnect
{
}
