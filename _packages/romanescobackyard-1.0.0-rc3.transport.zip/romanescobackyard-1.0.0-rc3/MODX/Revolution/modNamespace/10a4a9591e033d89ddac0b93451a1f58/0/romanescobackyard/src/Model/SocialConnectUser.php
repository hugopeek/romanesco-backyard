<?php
namespace FractalFarming\Romanesco\Model;

use xPDO\xPDO;

/**
 * Class SocialConnectUser
 *
 *
 * @package FractalFarming\Romanesco\Model
 */
class SocialConnectUser extends \FractalFarming\Romanesco\Model\SocialConnect
{
}
