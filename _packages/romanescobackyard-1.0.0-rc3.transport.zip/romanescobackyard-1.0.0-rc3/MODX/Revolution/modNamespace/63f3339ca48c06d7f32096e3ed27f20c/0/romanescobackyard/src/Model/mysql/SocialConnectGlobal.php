<?php
namespace FractalFarming\Romanesco\Model\mysql;

use xPDO\xPDO;

class SocialConnectGlobal extends \FractalFarming\Romanesco\Model\SocialConnectGlobal
{

    public static $metaMap = array (
        'package' => 'FractalFarming\\Romanesco\\Model',
        'version' => '3.0',
        'extends' => 'FractalFarming\\Romanesco\\Model\\SocialConnect',
        'tableMeta' => 
        array (
            'engine' => 'InnoDB',
        ),
        'fields' => 
        array (
        ),
        'fieldMeta' => 
        array (
        ),
    );

}
