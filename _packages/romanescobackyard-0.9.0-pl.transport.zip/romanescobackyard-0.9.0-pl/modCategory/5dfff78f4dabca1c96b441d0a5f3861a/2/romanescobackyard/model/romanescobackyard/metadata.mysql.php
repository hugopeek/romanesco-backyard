<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'rmTimeline',
    1 => 'rmNote',
    2 => 'rmCrosslink',
    3 => 'rmOption',
    4 => 'rmOptionGroup',
    5 => 'rmTimelineProject',
    6 => 'rmNoteImprovement',
    7 => 'rmNoteIssue',
    8 => 'rmCrosslinkRepurpose',
    9 => 'rmCrosslinkRelated',
  ),
);