<?php
/**
 * @package romanescobackyard
 */
class rmCrosslinkRelated extends xPDOSimpleObject {}
?>